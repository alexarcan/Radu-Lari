<footer>
      <!--  &copy;TIMpliber 2015. All rights reserved. -->
</footer>