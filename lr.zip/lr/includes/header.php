 <header>
     
        <?php include 'includes/menu.php'; ?>
        <div class="clear "></div>
    </header>