<?php 
	include 'core/init.php';
	include 'includes/overall/header.php'; 
?>



<img id="logo" src="./picture_logo/1.jpg"/>
<p id="text_log" >TIMp<span style="color:red">liber</span></p>

<br><br><br><br><br><br><br>
<h1>Despre noi</h1>
<p>sajfbhnf</p>

<?php include 'web-1.php';?>

<?php include 'includes/overall/footer.php'; ?>