$("#join").click(function(){
	 req = new ajaxRequest();
	 url = "join.php";
	 req.CallMethod(url,"");
	});