    <!DOCTYPE html>
<html>
    <head>
		<link rel="stylesheet" type="text/css" href="style_web-6.css">
	</head>
	<body>
	<h1>Evenimente artistice din Timisoara </h1>
	
	
	<div id="self1">
			<img src="I don't stop when I'm tired.jpg"  style="width:300px;height:150px;border:0;float:left;margin-right:20px">
			<h3>Mancare pe paine!!!</h3>
			<p>Vine Michelangelo la Timisoara!! Eveniment de neuitat <br> Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine Ana are mere dar se simte bine Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  fiind o culegatoare extraorinar de fantastica si brilianta</br>
			<br>Si Ralucaaa i-a furat merele!!!!!!!!!!!!!!!!!!!!! MUHAHAHAHAAAAAMUHAHAHAHAAAAAMUHAHAHAHAAAAAMUHAHAHAHAAAAAMUHAHAHAHAAAAAMUHAHAHAHAAAAAMUHAHAHAHAAAAA </br>
			</p>
	</div>
	<div id="self1">
			<img src="I don't stop when I'm tired.jpg"  style="width:300px;height:150px;border:0;float:left;margin-right:20px">
			<h3>Mancare pe paine!!!</h3>
			<p>Vine Michelangelo la Timisoara!! Eveniment de neuitat <br> Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine Ana are mere dar se simte bine Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  fiind o culegatoare extraorinar de fantastica si brilianta</br>
			<br>Si Ralucaaa i-a furat merele!!!!!!!!!!!!!!!!!!!!! MUHAHAHAHAAAAAMUHAHAHAHAAAAAMUHAHAHAHAAAAAMUHAHAHAHAAAAAMUHAHAHAHAAAAAMUHAHAHAHAAAAAMUHAHAHAHAAAAA </br>
			</p>
	</div>
	<div id="self1">
			<img src="I don't stop when I'm tired.jpg"  style="width:300px;height:150px;border:0;float:left;margin-right:20px">
			<h3>Mancare pe paine!!!</h3>
			<p>Vine Michelangelo la Timisoara!! Eveniment de neuitat <br> Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine Ana are mere dar se simte bine Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  fiind o culegatoare extraorinar de fantastica si brilianta</br>
			<br>Si Ralucaaa i-a furat merele!!!!!!!!!!!!!!!!!!!!! MUHAHAHAHAAAAAMUHAHAHAHAAAAAMUHAHAHAHAAAAAMUHAHAHAHAAAAAMUHAHAHAHAAAAAMUHAHAHAHAAAAAMUHAHAHAHAAAAA </br>
			</p>
	</div>
	<div id="self1">
			<img src="I don't stop when I'm tired.jpg"  style="width:300px;height:150px;border:0;float:left;margin-right:20px">
			<h3>Mancare pe paine!!!</h3>
			<p>Vine Michelangelo la Timisoara!! Eveniment de neuitat <br> Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine Ana are mere dar se simte bine Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  Ana are mere dar se simte bine  fiind o culegatoare extraorinar de fantastica si brilianta</br>
			<br>Si Ralucaaa i-a furat merele!!!!!!!!!!!!!!!!!!!!! MUHAHAHAHAAAAAMUHAHAHAHAAAAAMUHAHAHAHAAAAAMUHAHAHAHAAAAAMUHAHAHAHAAAAAMUHAHAHAHAAAAAMUHAHAHAHAAAAA </br>
			</p>
	</div>
	<body>
	
	
</html>