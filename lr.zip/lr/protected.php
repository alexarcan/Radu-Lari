<?php 
	include 'core/init.php';
	include 'includes/overall/header.php'; 
?>
<h1>Sorry, you need to be logged in to post events.</h1>
<p>Please register or log in.</p>

<?php include 'includes/overall/footer.php'; ?>