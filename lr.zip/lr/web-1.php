<!DOCTYPE html>
<html>
    <head>
		
		
        <meta charset="utf-8">
        <title>TIMp Liber</title>
		
		
		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1"> 
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>

		<!--<title>Login Form</title>-->
		<!--<link rel="stylesheet" href="css/style.css">-->
		<!--[if lt IE 9]><script src="//html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->
		
		<!--<link rel="import" href="searchbar.htm"> -->
		
		<link rel="stylesheet" type="text/css" href="sty.css">
		<link rel="stylesheet" type="text/css" href="search_style.css">
	</head>
	
    <body>
	   
		<h3><br><br><br><br><br><br><br>C&#259utare </h3>
	
		<form class="search" action ='./search.php' method='get'> 
			<input type='text' placeholder="Search..." required name='k' size='50'/>
			<button type='submit'>Caut&#259 </button>
		</form>
		
		
		
		
		<h2><br>C&#259utare &#238n func&#355ie de categorie:</br></h2>
		
		<div class="pic_browse1">
			
			<a href="http://localhost/Rezerva_lr/lr/web-2.php">
				<img  class="pic_grow1" src="pictures_mainpage/1.jpg" alt="Muzica"/>
			</a>
			<a href="http://localhost/Rezerva_lr/lr/web-2.php">
				<center id="text1">Muzic&#259 </center>
			</a>
		</div>
		
		
		<div class="pic_browse1">
			<a href="http://localhost/lr/web-3.php">
				<img class="pic_grow1" src="pictures_mainpage/2.jpg" alt="Sport"/> 
				</a>
				<a href="http://localhost/lr/web-3.php">
				<center id="text1">Sport</center>
			</a>
		</div>
		
		<div class="pic_browse1">
		<a href="http://localhost/lr/web-4.php">
		<img class="pic_grow1" src="pictures_mainpage/3.jpg" alt="Arta"/> 
		</a>
		<a href="http://localhost/lr/web-3.php">
		<center id="text1">Art&#259 </center>
		</a>
		</div>
		
		
		<div class="pic_browse2">
		<a href="http://localhost/lr/web-5.php">
		<img class="pic_grow2" src="pictures_mainpage/4.jpg" alt="Mancare"/> 
		</a>
		<a href="http://localhost/lr/web-5.php"">
		<center id="text1">M&#226nc&#259ruri </center>
		</a>
		</div>
		
		<div class="pic_browse2">
		<a href="http://localhost/lr/web-6.php">
		<img class="pic_grow2" src="pictures_mainpage/5.jpg" alt="Dezvoltare personala"/> 
		</a>
		<a href="http://localhost/lr/web-6.php"">
		<center id="text1">Dezvoltare personal&#259 </center>
		</a>
		</div>
		
		
		
		
		
		
		
		</body>
		</html>		